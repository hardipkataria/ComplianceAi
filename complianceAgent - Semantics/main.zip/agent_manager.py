import re
from langchain.agents import Tool, initialize_agent, AgentType
from langchain.memory import ConversationBufferMemory
from agents.fetcher_agent import get_failed_checks
from agents.analyzer_agent import analyze_checks
from agents.llm_agent import call_llm
from memory_store import get_chat_history
from tools.k8s_tools import list_all_scans
from tools.remediation_tool import generate_playbook
from tools.semantic_matcher import find_best_matching_rule
from tools.parser_tool import parse_user_input, extract_rule_id, extract_severity, is_remediation_query

# Shared memory for conversation
def get_memory():
    return ConversationBufferMemory(memory_key="chat_history", return_messages=True)

# Helper: Extract latest scan name from chat history
def extract_latest_scan_from_history(chat_history: list) -> str | None:
    for message in reversed(chat_history or []):
        if isinstance(message, str):
            text = message
        elif hasattr(message, "content"):
            text = message.content
        else:
            continue
        match = re.search(r"(ocp4-[\w\-]+)", text.lower())
        if match:
            return match.group(1)
    return None

# Helper: Fallback to latest scan from cluster
def get_latest_scan_from_cluster() -> str | None:
    scans = list_all_scans()
    return scans[-1] if scans else None

# Tool dictionary for routing logic
tools = {
    "GetComplianceIssues": lambda scan_name=None: (
        print(f"[DEBUG] → get_failed_checks(scan_name={scan_name})") or
        get_failed_checks(scan_name)
    ),
    "AnalyzeChecks": lambda severity, scan_name=None: (
        print(f"[DEBUG] → analyze_checks(severity={severity}, scan_name={scan_name})") or
        analyze_checks(severity, scan_name)
    ),
    "GenerateRemediation": generate_playbook,
    "ListAllScans": list_all_scans,
    "SemanticMatchRule": find_best_matching_rule,
    "ParseInput": parse_user_input
}

# Direct routing logic
def route_directly(user_input: str, chat_history: list) -> str | None:
    print(f"[DEBUG] User input: {user_input}")

    rule_id = extract_rule_id(user_input)
    severity = extract_severity(user_input)
    is_remediation = is_remediation_query(user_input)

    # Try to extract scan name from user input
    scan_match = re.search(r"(ocp4-[\w\-]+)", user_input.lower())
    if scan_match:
        scan_name = scan_match.group(1)
    else:
        scan_name = extract_latest_scan_from_history(chat_history) or get_latest_scan_from_cluster()

    print(f"[PARSED INPUT] Rule: {rule_id}, Severity: {severity}, Remediation: {is_remediation}, Scan: {scan_name}")

    #if "list all scans" in user_input.lower():
    if any(kw in user_input.lower() for kw in ["list all scan", "list all scans", "show all scan", "show all scans"]):
        print("[ROUTE] → ListAllScans")
        return tools["ListAllScans"]()

    if rule_id and is_remediation:
        print(f"[ROUTE] → GenerateRemediation for rule {rule_id}")
        return tools["GenerateRemediation"](rule_id)

    if is_remediation and not rule_id:
        print("[ROUTE] → GenerateRemediation (all failed rules)")
        return tools["GenerateRemediation"]("")

    if severity in ("critical", "medium", "high", "low"):
        print(f"[ROUTE] → AnalyzeChecks for severity {severity}, scan={scan_name}")
        return tools["AnalyzeChecks"](severity, scan_name)

    if "failed" in user_input.lower() or "non-compliant" in user_input.lower():
        print(f"[ROUTE] → GetComplianceIssues (scan={scan_name})")
        return tools["GetComplianceIssues"](scan_name)

    return None  # fallback to LLM agent


# Main agent function
def run_compliance_agent(user_input, chat_history):
    # First try direct routing
    direct_response = route_directly(user_input, chat_history)
    if direct_response is not None:
        return direct_response

    # Define tools for the agent
    agent_tools = [
        Tool(name="GetComplianceIssues", func=tools["GetComplianceIssues"], description="Fetch all failed compliance rules."),
        Tool(name="AnalyzeChecks", func=tools["AnalyzeChecks"], description="Filter compliance rules by severity or rule ID."),
        Tool(name="GenerateRemediation", func=tools["GenerateRemediation"], description="Generate Ansible remediation for failed rules."),
        Tool(name="ListAllScans", func=tools["ListAllScans"], description="List all compliance scan names."),
        Tool(name="SemanticMatchRule", func=tools["SemanticMatchRule"], description="Find best matching compliance rule using semantic search."),
        Tool(name="ParseInput", func=tools["ParseInput"], description="Parse input to extract rule ID, scan name, or severity.")
    ]

    memory = get_memory()

    agent = initialize_agent(
        tools=agent_tools,
        llm=call_llm(),
        agent=AgentType.CHAT_CONVERSATIONAL_REACT_DESCRIPTION,
        memory=memory,
        verbose=True,
        handle_parsing_errors=True
    )

    print(f"[DEBUG] Invoking full agent for input: {user_input}")

    try:
        result = agent.invoke({
            "input": user_input,
            "chat_history": chat_history or get_chat_history()
        })
        print(f"[DEBUG] Agent output: {result}")
        return result["output"]
    except Exception as e:
        print(f"[ERROR] Agent failed: {e}")
        return str(e)
