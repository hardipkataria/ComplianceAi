# analyzer_agent.py

from tools.k8s_tools import fetch_compliance_failures

def analyze_checks(severity: str, scan_name: str | None = None) -> str:
    """Filters failed checks by severity.

    Args:
        severity (str): Severity level to filter ("low", "medium", "high", "critical").
        scan_name (str | None): Optional scan name to filter within.

    Returns:
        str: Filtered list of failed rules.
    """
    severity = severity.lower()
    failures = fetch_compliance_failures(scan_name)

    if not failures:
        return f"No failed checks found for scan '{scan_name}'." if scan_name else "No failed compliance checks found."

    filtered = [
        r for r in failures if r["severity"].lower() == severity
    ]

    if not filtered:
        return f"No '{severity}' severity issues found in scan '{scan_name}'." if scan_name else f"No '{severity}' severity issues found."

    return "\n".join(
        f"{r['id']} - {r['description']} (Severity: {r['severity']})"
        for r in filtered
    )


import re

def analyze_scan_list(scans: list[dict], user_input: str) -> str:
    user_input_lower = user_input.lower()

    # Define filters
    status_filter = None
    result_filter = None

    # Detect status (e.g., "status done", "only done scans")
    status_match = re.search(r'\bstatus\s*[:=]?\s*(\w+)', user_input_lower)
    if status_match:
        status_filter = status_match.group(1).upper()
    elif "done" in user_input_lower:
        status_filter = "DONE"
    elif "pending" in user_input_lower:
        status_filter = "PENDING"

    # Detect result (e.g., "result non-compliant", "show compliant", etc.)
    if "non-compliant" in user_input_lower:
        result_filter = "NON-COMPLIANT"
    elif "compliant" in user_input_lower:
        result_filter = "COMPLIANT"
    elif "not applicable" in user_input_lower or "not-applicable" in user_input_lower:
        result_filter = "NOT-APPLICABLE"

    # Filter scans
    filtered_scans = []
    for scan in scans:
        status = scan.get("status", {}).get("phase", "").upper()
        result = scan.get("status", {}).get("result", "").upper()

        if status_filter and status != status_filter:
            continue
        if result_filter and result != result_filter:
            continue

        filtered_scans.append({
            "name": scan.get("metadata", {}).get("name", "<unknown>"),
            "status": status,
            "result": result,
            "profile": scan.get("spec", {}).get("profile", "-")
        })

    if not filtered_scans:
        return f"No compliance scans found matching the given criteria: {user_input}"

    # Format output
    lines = ["📝 Matching Compliance Scans:\n"]
    for scan in filtered_scans:
        lines.append(
            f"• {scan['name']} — Status: {scan['status']} — Result: {scan['result']} — Profile: {scan['profile']}"
        )

    return "\n".join(lines)

