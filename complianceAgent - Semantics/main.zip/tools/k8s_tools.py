# Fetch compliance scans via Kubernetes client
from kubernetes import client, config

GROUP = "compliance.openshift.io"
VERSION = "v1alpha1"
NAMESPACE = "qsafe-engineers"

config.load_kube_config()
custom_api = client.CustomObjectsApi()

#returns a list of scan names pulled from cluster resources (via command or API).
def list_all_scans(_: str = "") -> list[dict]:
    scans = custom_api.list_namespaced_custom_object(
        group=GROUP,
        version=VERSION,
        namespace=NAMESPACE,
        plural="compliancescans"
    )
    return "\n".join(scan["metadata"]["name"] for scan in scans.get("items", []))


def fetch_compliance_failures(scan_name: str = None):
    print(f"[TOOL DEBUG] Called: GetComplianceIssues with scan_name: {scan_name}")

    failed = []
    try:
        check_results = custom_api.list_namespaced_custom_object(
            group=GROUP,
            version=VERSION,
            namespace=NAMESPACE,
            plural="compliancecheckresults"
        )
    except Exception as e:
        print(f"[TOOL ERROR] Failed to fetch compliance check results: {e}")
        return failed

    for result in check_results.get("items", []):
        if result.get("status") != "FAIL":
            continue

        metadata = result.get("metadata", {})
        result_name = metadata.get("name", "unknown")
        owner_refs = metadata.get("ownerReferences", [])
        result_scan_name = owner_refs[0]["name"] if owner_refs else ""

        # If a specific scan is requested, filter by it
        if scan_name and result_scan_name != scan_name:
            continue

        failed.append({
            "id": result_name,
            "description": result.get("description", "N/A"),
            "severity": result.get("severity", "unknown"),
            "rationale": result.get("rationale", "Not provided"),
            "remediation": result.get("instructions", "Not provided"),
            "scan": result_scan_name
        })

    print(f"[TOOL DEBUG] Found {len(failed)} failed check(s)")
    return failed