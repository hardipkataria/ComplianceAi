# tools/parser_tool.py

import re

def extract_rule_id(user_input: str) -> str:
    """
    Tries to find a rule ID like 'ocp4-cis-...' in the input string.
    """
    match = re.search(r"(ocp4-[\w\-]+)", user_input.lower())
    return match.group(1) if match else ""

def extract_severity(user_input: str) -> str:
    """
    Returns 'critical', 'medium', or 'all' based on user query.
    """
    lowered = user_input.lower()
    if "critical" in lowered:
        return "critical"
    elif "medium" in lowered:
        return "medium"
    return "all"

def is_remediation_query(user_input: str) -> bool:
    """
    Detect if user is asking for remediation steps.
    """
    return any(word in user_input.lower() for word in ["remediation", "how to fix", "resolve", "mitigate"])

#wrapper parser
def parse_user_input(user_input: str) -> dict:
    return {
        "rule_id": extract_rule_id(user_input),
        "severity": extract_severity(user_input),
        "is_remediation": is_remediation_query(user_input)
    }