import re
from tools.k8s_tools import fetch_compliance_failures

def generate_playbook(input_text: str) -> str:
    """
    Generate remediation for a specific failed rule (by ID or description),
    or all failed rules based on user input.
    """
    failed = fetch_compliance_failures()
    input_lower = input_text.lower()

    # Case 1: Remediate ALL rules
    if "all" in input_lower or "remediate all" in input_lower:
        playbooks = []
        for rule in failed:
            playbooks.append(
                f"🔧 **{rule['id']}**\n{rule.get('remediation', 'No remediation available.')}"
            )
        return "\n\n".join(playbooks) if playbooks else "✅ No failed rules found to remediate."

    # Case 2: Try to match a specific rule by ID or phrase in description
    matched_rule = None
    for rule in failed:
        if (
            rule["id"].lower() in input_lower
            or rule["description"].lower() in input_lower
            or any(kw in input_lower for kw in rule["description"].lower().split())
        ):
            matched_rule = rule
            break

    if matched_rule:
        return (
            f"🔧 **Remediation for {matched_rule['id']}**\n\n"
            f"{matched_rule.get('remediation', 'No remediation available.')}"
        )

    return (
        "⚠️ Could not find a specific failed rule matching your request.\n\n"
        "Try including a rule ID or a more exact description from the compliance scan."
    )
