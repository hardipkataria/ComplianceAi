# Generates remediation steps / Ansible playbook
import html

from tools.k8s_tools import fetch_compliance_failures
from typing import List

def generate_playbook(input_text: str) -> str:
    print(f"[TOOL DEBUG] Called: GenerateRemediation with input: {input_text}")

    """
    Generate an Ansible playbook from failed compliance issues.
    If a specific rule is mentioned in the input, generate for that.
    Otherwise, generate for top 3 failed checks.
    """
    failures = fetch_compliance_failures()

    # Try to find rule-specific match in user input
    selected = []
    for rule in failures:
        if rule["id"].lower() in input_text.lower():
            selected = [rule]
            break

    if not selected:
        selected = failures[:3]  # Only the top 3 failures limitting due to tokens in openAI

    playbook = [
        "---",
        "- name: Auto-generated Remediation Playbook",
        "  hosts: all",
        "  become: true",
        "  tasks:"
    ]

    for rule in selected:
        remediation = html.escape(rule.get("remediation", "No remediation available."))
        playbook.append(f"  - name: Remediate {rule['id']}")
        playbook.append("    debug:")
        playbook.append(f"      msg: \"{remediation}\"")

    return "\n".join(playbook)
