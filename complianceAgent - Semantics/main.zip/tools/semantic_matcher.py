# tools/semantic_matcher.py
#The goal of this module is to allow users to ask natural language questions
# or request remediation without knowing the exact compliance rule ID or phrasing.
import os

import dotenv
import faiss
import numpy as np
from langchain.embeddings import OpenAIEmbeddings
from tools.k8s_tools import fetch_compliance_failures

#load env
dotenv.load_dotenv()

# Load OpenAI API Key
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Initialize embedding model
embedding_model = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)

# Global cache for FAISS index and rule mapping
_index = None
_rule_texts = []

def build_index():
    global _index, _rule_texts

    failed_checks = fetch_compliance_failures()
    if not failed_checks:
        return

    _rule_texts = [f"{r['id']}: {r['description']}" for r in failed_checks]
    embeddings = embedding_model.embed_documents(_rule_texts)

    dim = len(embeddings[0])
    _index = faiss.IndexFlatL2(dim)
    _index.add(np.array(embeddings).astype("float32"))

#searches the pre-indexed compliance rules using vector similarity.
def find_best_matching_rule(user_query: str) -> str:
    global _index, _rule_texts

    if _index is None or not _rule_texts:
        build_index()
        if _index is None:
            return "❌ Could not build index from failed checks."

    query_vector = embedding_model.embed_query(user_query)
    D, I = _index.search(np.array([query_vector]).astype("float32"), k=1)

    if not I[0].size or I[0][0] >= len(_rule_texts):
        return "❌ No matching rule found."

    best_match = _rule_texts[I[0][0]]
    return f"🔎 Best Match:\n{best_match}"
